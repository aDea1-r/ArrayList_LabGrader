//(c) A+ Computer Science
//www.apluscompsci.com
//Name -
//Date -

import java.util.List;
import java.util.ArrayList;

public class ListNoRepeats
{
	//method go will return true if there
	//are no numbers that repeat
	//false if any numbers repeat
	public static boolean go( List<Integer> ray)
	{
		boolean caught = false;
		for (int x=0; x<ray.size(); x++)
		{
			for (int y=0; y<x; y++)
			{
				if (ray.get(x).equals(ray.get(y)))
					caught = true;
			}
		}
		return !caught;
	}
}
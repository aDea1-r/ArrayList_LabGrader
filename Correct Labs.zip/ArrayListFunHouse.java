//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import static java.lang.System.*;

public class ArrayListFunHouse
{
	public static ArrayList<Integer> getListOfFactors(int number)
	{
		ArrayList<Integer> output = new ArrayList<Integer>();
		for (int x=2;x<number;x++)
		{
			if (number%x==0)
				output.add(x);
		}
		return output; 
	}
	
	public static void keepOnlyCompositeNumbers( List<Integer> nums )
	{
		for (int i=0;i<nums.size();i++)
		{
			if (getListOfFactors(nums.get(i)).size()==0)
			{
				nums.remove(i);
				i--;
			}
		}
	}
}
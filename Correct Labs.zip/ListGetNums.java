//(c) A+ Computer Science
//www.apluscompsci.com
//Name -
//Date -

import java.util.List;
import java.util.ArrayList;

public class ListGetNums
{
	//method go will return an array
	//containing the first 3 numbers
	//greater than 11
	public static List<Integer> go( List<Integer> ray )
	{
		List<Integer> output = new ArrayList<Integer>();
		for (int x=0; x<ray.size() && output.size()<3; x++)
		{
			if (ray.get(x)>11)
				output.add(ray.get(x));
		}
		return output; 
	}
}
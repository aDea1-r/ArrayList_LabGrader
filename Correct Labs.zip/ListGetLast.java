//(c) A+ Computer Science
//www.apluscompsci.com
//Name -
//Date -

import java.util.*;

public class ListGetLast
{
	//method go will return a list
	//containing the all of the values greater 
	//than the last value in the list
	public static List<Integer> go(  List<Integer> ray )
	{
		List<Integer> output = new ArrayList<Integer>();
		
		if (ray.size()==0) 
			return output;
		
		int max = ray.get(ray.size()-1);
		for (int x: ray)
		{
			if (x>max)
				output.add(x);
		}
		return output; 
	}
}
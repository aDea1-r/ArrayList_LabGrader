//(c) A+ Computer Science
//www.apluscompsci.com
//Name -
//Date -

import java.util.*;

public class ListMostFreq
{
	//method go will return the value 
	//that appears the most
	//if several numbers all appear
	//the same number of times
	//return the first number found
	public static int go( List<Integer> ray )
	{
		ArrayList<Integer> freq = new ArrayList<Integer>();
		
		int count = 0; 
		for (int x=0; x<ray.size(); x++)
		{
			//System.out.println("Loop1 Started");
			for (int y=0; y<ray.size(); y++)
			{
				//System.out.println("Loop2 Started");
				if (ray.get(x).equals(ray.get(y)))
				{
					//System.out.println("If1 Started");
					count++;
				}
			}
			freq.add(x,count);
			count=0;
		}
		
		int maxspot = 0;
		for (int x=0; x<freq.size();x++)
		{
			if (freq.get(x)>freq.get(maxspot))
			{
				maxspot = x;
				//System.out.println("maxspot: "+x);
			}
		}
		//System.out.println("input: "+ray);
		//System.out.println(freq);
		//System.out.println("spot: "+maxspot);
		return ray.get(maxspot);
	}
}
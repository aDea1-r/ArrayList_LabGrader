//(c) A+ Computer Science
//www.apluscompsci.com
//Name -
//Date -

import java.util.ArrayList;
import java.util.List;

public class ListTotal
{
	public static int go( List<Integer> ray )
	{
		int total = 0; 
		for (int x = 0; x< ray.size(); x++)
		{
			total+=ray.get(x);
		}
		return total; 
	}
}
//(c) A+ Computer Science
//www.apluscompsci.com
//Name -
//Date -

import java.util.List;
import java.util.ArrayList;

public class ListAverage
{
	public static double go( List<Integer> ray)
	{
		int min = ray.get(0);
		int max = ray.get(0);
		for (int x: ray) {
			min = Math.min(min,x);
			max = Math.max(max,x);
		}
		return (min+max)/2.0;
	}
}
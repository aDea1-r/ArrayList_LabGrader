//(c) A+ Computer Science
//www.apluscompsci.com
//Name -
//Date -

import java.util.ArrayList;
import java.util.List;

public class ListOddToEven
{
	public static int go( List<Integer> ray )
	{
		int oddspot = 0;
		int evenspot=0;
		boolean hasFound=false;
		
		for (int x=0;x<ray.size();x++)
		{
			if (hasFound==false && ray.get(x)%2==1)
			{	
				oddspot = x;
				hasFound=true;				
			}
		}
		if (hasFound==false) return -1;
		
		hasFound=false;
		
		for (int x=oddspot+1;x<ray.size();x++)
		{
			if (ray.get(x)%2==0)
			{
				evenspot = x;
				hasFound=true;
			}				
		}
		if (hasFound==false) return -1;
	
		return evenspot-oddspot;
	}
}
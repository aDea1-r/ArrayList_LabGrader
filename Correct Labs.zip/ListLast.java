//(c) A+ Computer Science
//www.apluscompsci.com
//Name -
//Date -

import java.util.ArrayList;
import java.util.List;

public class ListLast
{
	public static boolean go(List<Integer> ray)
	{
		if (ray.size()==0)
			return false;
		return ray.indexOf(ray.get(ray.size()-1))!=ray.size()-1;
	}
}